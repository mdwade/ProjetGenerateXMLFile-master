package com.gn;

public class Bibliotheque{
private Livre livre;
public void setLivre (Livre livre){
this.livre = livre;
}
public Livre getLivre (){
return this.livre;
}

public Bibliotheque(){}}



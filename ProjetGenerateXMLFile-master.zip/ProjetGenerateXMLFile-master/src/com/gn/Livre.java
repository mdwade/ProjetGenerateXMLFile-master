package com.gn;

public class Livre{
private String titre;
public void setTitre (String titre){
this.titre = titre;
}
public String getTitre (){
return this.titre;
}
private String auteur;
public void setAuteur (String auteur){
this.auteur = auteur;
}
public String getAuteur (){
return this.auteur;
}
private String editeur;
public void setEditeur (String editeur){
this.editeur = editeur;
}
public String getEditeur (){
return this.editeur;
}

public Livre(){}}


